data:extend(
{
  {
    type = "bool-setting",
    name = "bobmods-tech-colorupdate",
    setting_type = "startup",
    default_value = true,
  },
}
)


