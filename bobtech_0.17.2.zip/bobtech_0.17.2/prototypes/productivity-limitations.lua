bobmods.lib.module.add_productivity_limitation("advanced-logistic-science-pack")

if data.raw.recipe["science-pack-gold"] then
  bobmods.lib.module.add_productivity_limitation("science-pack-gold")
end

if data.raw.recipe["alien-science-pack-blue"] then
  bobmods.lib.module.add_productivity_limitation("alien-science-pack-blue")
end

if data.raw.recipe["alien-science-pack-orange"] then
  bobmods.lib.module.add_productivity_limitation("alien-science-pack-orange")
end

if data.raw.recipe["alien-science-pack-purple"] then
  bobmods.lib.module.add_productivity_limitation("alien-science-pack-purple")
end

if data.raw.recipe["alien-science-pack-yellow"] then
  bobmods.lib.module.add_productivity_limitation("alien-science-pack-yellow")
end

if data.raw.recipe["alien-science-pack-green"] then
  bobmods.lib.module.add_productivity_limitation("alien-science-pack-green")
end

if data.raw.recipe["alien-science-pack-red"] then
  bobmods.lib.module.add_productivity_limitation("alien-science-pack-red")
end


