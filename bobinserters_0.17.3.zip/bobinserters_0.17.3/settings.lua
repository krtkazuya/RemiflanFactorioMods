data:extend(
{
  {
    type = "bool-setting",
    name = "bobmods-inserters-long2",
    setting_type = "startup",
    default_value = true,
  },
  {
    type = "bool-setting",
    name = "bobmods-inserters-more2",
    setting_type = "startup",
    default_value = true,
  },
  {
    type = "bool-setting",
    name = "bobmods-inserters-dual-mode",
    setting_type = "runtime-per-user",
    default_value = false,
  },
}
)


