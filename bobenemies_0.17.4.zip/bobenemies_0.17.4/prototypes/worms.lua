local function worm_animations(scale, tint)
  local val = {}
  val.folded_animation = worm_folded_animation(scale, tint)
  val.preparing_animation = worm_preparing_animation(scale, tint, "forward")
  val.prepared_animation = worm_prepared_animation(scale, tint)
  val.prepared_alternative_animation = worm_prepared_alternative_animation(scale, tint)
  val.starting_attack_animation = worm_start_attack_animation(scale, tint)
  val.ending_attack_animation = worm_end_attack_animation(scale, tint)
  val.folding_animation =  worm_preparing_animation(scale, tint, "backward")
  return val
end

local function set_worm_animations(entiy, scale, tint)
  entiy.folded_animation = worm_folded_animation(scale, tint)
  entiy.preparing_animation = worm_preparing_animation(scale, tint, "forward")
  entiy.prepared_animation = worm_prepared_animation(scale, tint)
  entiy.prepared_alternative_animation = worm_prepared_alternative_animation(scale, tint)
  entiy.starting_attack_animation = worm_start_attack_animation(scale, tint)
  entiy.ending_attack_animation = worm_end_attack_animation(scale, tint)
  entiy.folding_animation =  worm_preparing_animation(scale, tint, "backward")
end



set_worm_animations(data.raw.turret["big-worm-turret"], scale_worm_big, bob_acid_worm_tint)
table.insert(data.raw.turret["big-worm-turret"].resistances,{type = "acid", decrease = 5, percent = 40})

data.raw.corpse["big-worm-corpse"].animation = worm_die_animation(scale_worm_big, bob_acid_worm_tint)

set_worm_animations(data.raw.turret["behemoth-worm-turret"], bob_behemoth_scale, tint_worm_behemoth)
data.raw.turret["behemoth-worm-turret"].collision_box = {{-2.8, -2.4}, {2.8, 2.4}}
data.raw.turret["behemoth-worm-turret"].selection_box = {{-2.8, -2.4}, {2.8, 2.4}}
data.raw.turret["behemoth-worm-turret"].map_generator_bounding_box = {{-3.8, -3.4}, {3.8, 3.4}}

data.raw.corpse["behemoth-worm-corpse"].animation = worm_die_animation(bob_behemoth_scale, tint_worm_behemoth)


data:extend(
{
  {
    type = "turret",
    name = "bob-big-explosive-worm-turret",
    icon = "__base__/graphics/icons/big-worm.png",
    icon_size = 32,
    flags = {"placeable-player", "placeable-enemy", "not-repairable", "breaths-air"},
    max_health = 500,
    order="b-b-g",
    subgroup="enemies",
    resistances =
    {
      {
        type = "physical",
        decrease = 8,
      },
      {
        type = "explosion",
        decrease = 15,
        percent = 50,
      }
    },
    healing_per_tick = 0.02,
    collision_box = {{-1.4, -1.2}, {1.4, 1.2}},
    selection_box = {{-1.4, -1.2}, {1.4, 1.2}},
    map_generator_bounding_box = {{-2.4, -2.2}, {2.4, 2.2}},
    shooting_cursor_size = 4,
    rotation_speed = 1,
    corpse = "bob-big-explosive-worm-corpse",
    dying_explosion = "blood-explosion-big",
    dying_sound = make_worm_dying_sounds(1.0),
    folded_speed = 0.01,
    folded_animation = worm_folded_animation(scale_worm_big, bob_explosive_worm_tint),
    prepare_range = 25,
    preparing_speed = 0.025,
    preparing_animation = worm_preparing_animation(scale_worm_big, bob_explosive_worm_tint, "forward"),
    prepared_speed = 0.015,
    prepared_animation = worm_prepared_animation(scale_worm_big, bob_explosive_worm_tint),
    starting_attack_speed = 0.03,
    starting_attack_animation = worm_start_attack_animation(scale_worm_big, bob_explosive_worm_tint),
    starting_attack_sound = make_worm_roars(0.95),
    ending_attack_speed = 0.03,
    ending_attack_animation = worm_end_attack_animation(scale_worm_big, bob_explosive_worm_tint, "backward"),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(scale_worm_big, bob_explosive_worm_tint, "backward"),
    prepare_range = 30,
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "biological",
      cooldown = 60,
      range = 26,
      projectile_creation_distance = 2.1,
      damage_modifier = 5,
      use_shooter_direction = true,
      lead_target_for_projectile_speed = 0.5,
      ammo_type =
      {
        category = "biological",
        target_type = "position",
        clamp_position = true,
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "explosive-spit-projectile",
            starting_speed = 0.5,
            max_range = 50
          }
        }
      }
    },
    build_base_evolution_requirement = 0.5,
    autoplace = enemy_autoplace.enemy_worm_autoplace(5),
    call_for_help_radius = 40
  },

  {
    type = "turret",
    name = "bob-big-fire-worm-turret",
    icon = "__base__/graphics/icons/big-worm.png",
    icon_size = 32,
    flags = {"placeable-player", "placeable-enemy", "not-repairable", "breaths-air"},
    max_health = 500,
    order="b-b-g",
    subgroup="enemies",
    resistances =
    {
      {
        type = "physical",
        decrease = 8,
      },
      {
        type = "explosion",
        decrease = 10,
        percent = 25,
      },
      {
        type = "fire",
        decrease = 5,
        percent = 40,
      },
    },
    healing_per_tick = 0.02,
    collision_box = {{-1.4, -1.2}, {1.4, 1.2}},
    selection_box = {{-1.4, -1.2}, {1.4, 1.2}},
    map_generator_bounding_box = {{-2.4, -2.2}, {2.4, 2.2}},
    shooting_cursor_size = 4,
    rotation_speed = 1,
    corpse = "bob-big-fire-worm-corpse",
    dying_explosion = "blood-explosion-big",
    dying_sound = make_worm_dying_sounds(1.0),
    folded_speed = 0.01,
    folded_animation = worm_folded_animation(scale_worm_big, bob_fire_worm_tint),
    prepare_range = 25,
    preparing_speed = 0.025,
    preparing_animation = worm_preparing_animation(scale_worm_big, bob_fire_worm_tint, "forward"),
    prepared_speed = 0.015,
    prepared_animation = worm_prepared_animation(scale_worm_big, bob_fire_worm_tint),
    starting_attack_speed = 0.03,
    starting_attack_animation = worm_start_attack_animation(scale_worm_big, bob_fire_worm_tint, "forward"),
    starting_attack_sound = make_worm_roars(0.95),
    ending_attack_speed = 0.03,
    ending_attack_animation = worm_end_attack_animation(scale_worm_big, bob_fire_worm_tint, "backward"),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(scale_worm_big, bob_fire_worm_tint, "backward"),
    prepare_range = 30,
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "biological",
      cooldown = 60,
      range = 26,
      projectile_creation_distance = 2.1,
      damage_modifier = 5,
      use_shooter_direction = true,
      lead_target_for_projectile_speed = 0.5,
      ammo_type =
      {
        category = "biological",
        target_type = "position",
        clamp_position = true,
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "fire-spit-projectile",
            starting_speed = 0.5,
            max_range = 50
          }
        }
      }
    },
    build_base_evolution_requirement = 0.5,
    autoplace = enemy_autoplace.enemy_worm_autoplace(5),
    call_for_help_radius = 40
  },

  {
    type = "turret",
    name = "bob-big-poison-worm-turret",
    icon = "__base__/graphics/icons/big-worm.png",
    icon_size = 32,
    flags = {"placeable-player", "placeable-enemy", "not-repairable", "breaths-air"},
    max_health = 500,
    order="b-b-g",
    subgroup="enemies",
    resistances =
    {
      {
        type = "physical",
        decrease = 8,
      },
      {
        type = "explosion",
        decrease = 10,
        percent = 25,
      },
      {
        type = "poison",
        decrease = 5,
        percent = 40,
      }
    },
    healing_per_tick = 0.02,
    collision_box = {{-1.4, -1.2}, {1.4, 1.2}},
    selection_box = {{-1.4, -1.2}, {1.4, 1.2}},
    map_generator_bounding_box = {{-2.4, -2.2}, {2.4, 2.2}},
    shooting_cursor_size = 4,
    rotation_speed = 1,
    corpse = "bob-big-poison-worm-corpse",
    dying_explosion = "blood-explosion-big",
    dying_sound = make_worm_dying_sounds(1.0),
    folded_speed = 0.01,
    folded_animation = worm_folded_animation(scale_worm_big, bob_poison_worm_tint),
    prepare_range = 25,
    preparing_speed = 0.025,
    preparing_animation = worm_preparing_animation(scale_worm_big, bob_poison_worm_tint, "forward"),
    prepared_speed = 0.015,
    prepared_animation = worm_prepared_animation(scale_worm_big, bob_poison_worm_tint),
    starting_attack_speed = 0.03,
    starting_attack_animation = worm_start_attack_animation(scale_worm_big, bob_poison_worm_tint, "forward"),
    starting_attack_sound = make_worm_roars(0.95),
    ending_attack_speed = 0.03,
    ending_attack_animation = worm_end_attack_animation(scale_worm_big, bob_poison_worm_tint, "backward"),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(scale_worm_big, bob_poison_worm_tint, "backward"),
    prepare_range = 30,
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "biological",
      cooldown = 60,
      range = 26,
      projectile_creation_distance = 2.1,
      damage_modifier = 5,
      use_shooter_direction = true,
      lead_target_for_projectile_speed = 0.5,
      ammo_type =
      {
        category = "biological",
        target_type = "position",
        clamp_position = true,
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "poison-spit-projectile",
            starting_speed = 0.5,
            max_range = 50
          }
        }
      }
    },
    build_base_evolution_requirement = 0.5,
    autoplace = enemy_autoplace.enemy_worm_autoplace(5),
    call_for_help_radius = 40
  },


  {
    type = "turret",
    name = "bob-big-piercing-worm-turret",
    icon = "__base__/graphics/icons/big-worm.png",
    icon_size = 32,
    flags = {"placeable-player", "placeable-enemy", "not-repairable", "breaths-air"},
    max_health = 500,
    order="b-b-g",
    subgroup="enemies",
    resistances =
    {
      {
        type = "physical",
        decrease = 8,
      },
      {
        type = "explosion",
        decrease = 10,
        percent = 25,
      },
      {
        type = "bob-pierce",
        decrease = 5,
        percent = 40,
      }
    },
    healing_per_tick = 0.02,
    collision_box = {{-1.4, -1.2}, {1.4, 1.2}},
    selection_box = {{-1.4, -1.2}, {1.4, 1.2}},
    map_generator_bounding_box = {{-2.4, -2.2}, {2.4, 2.2}},
    shooting_cursor_size = 4,
    rotation_speed = 1,
    corpse = "bob-big-piercing-worm-corpse",
    dying_explosion = "blood-explosion-big",
    dying_sound = make_worm_dying_sounds(1.0),
    folded_speed = 0.01,
    folded_animation = worm_folded_animation(scale_worm_big, bob_pierce_worm_tint),
    prepare_range = 25,
    preparing_speed = 0.025,
    preparing_animation = worm_preparing_animation(scale_worm_big, bob_pierce_worm_tint, "forward"),
    prepared_speed = 0.015,
    prepared_animation = worm_prepared_animation(scale_worm_big, bob_pierce_worm_tint),
    starting_attack_speed = 0.03,
    starting_attack_animation = worm_start_attack_animation(scale_worm_big, bob_pierce_worm_tint, "forward"),
    starting_attack_sound = make_worm_roars(0.95),
    ending_attack_speed = 0.03,
    ending_attack_animation = worm_end_attack_animation(scale_worm_big, bob_pierce_worm_tint, "backward"),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(scale_worm_big, bob_pierce_worm_tint, "backward"),
    prepare_range = 30,
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "biological",
      cooldown = 60,
      range = 26,
      projectile_creation_distance = 2.1,
      damage_modifier = 6,
      use_shooter_direction = true,
      lead_target_for_projectile_speed = 0.5,
      ammo_type =
      {
        category = "biological",
        target_type = "position",
        clamp_position = true,
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "piercing-spit-projectile",
            starting_speed = 0.5
          }
        }
      }
    },
    build_base_evolution_requirement = 0.5,
    autoplace = enemy_autoplace.enemy_worm_autoplace(5),
    call_for_help_radius = 40
  },

  {
    type = "turret",
    name = "bob-big-electric-worm-turret",
    icon = "__base__/graphics/icons/big-worm.png",
    icon_size = 32,
    flags = {"placeable-player", "placeable-enemy", "not-repairable", "breaths-air"},
    max_health = 500,
    order="b-b-g",
    subgroup="enemies",
    resistances =
    {
      {
        type = "physical",
        decrease = 8,
      },
      {
        type = "explosion",
        decrease = 10,
        percent = 25,
      },
      {
        type = "electric",
        decrease = 5,
        percent = 40,
      }
    },
    healing_per_tick = 0.02,
    collision_box = {{-1.4, -1.2}, {1.4, 1.2}},
    selection_box = {{-1.4, -1.2}, {1.4, 1.2}},
    map_generator_bounding_box = {{-2.4, -2.2}, {2.4, 2.2}},
    shooting_cursor_size = 4,
    rotation_speed = 1,
    corpse = "bob-big-electric-worm-corpse",
    dying_explosion = "blood-explosion-big",
    dying_sound = make_worm_dying_sounds(1.0),
    folded_speed = 0.01,
    folded_animation = worm_folded_animation(scale_worm_big, bob_electric_worm_tint),
    prepare_range = 25,
    preparing_speed = 0.025,
    preparing_animation = worm_preparing_animation(scale_worm_big, bob_electric_worm_tint, "forward"),
    prepared_speed = 0.015,
    prepared_animation = worm_prepared_animation(scale_worm_big, bob_electric_worm_tint),
    starting_attack_speed = 0.03,
    starting_attack_animation = worm_start_attack_animation(scale_worm_big, bob_electric_worm_tint, "forward"),
    starting_attack_sound = make_worm_roars(0.95),
    ending_attack_speed = 0.03,
    ending_attack_animation = worm_end_attack_animation(scale_worm_big, bob_electric_worm_tint, "backward"),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(scale_worm_big, bob_electric_worm_tint, "backward"),
    prepare_range = 30,
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "biological",
      cooldown = 60,
      range = 26,
      projectile_creation_distance = 2.1,
      damage_modifier = 5,
      use_shooter_direction = true,
      lead_target_for_projectile_speed = 0.5,
      ammo_type =
      {
        category = "biological",
        target_type = "position",
        clamp_position = true,
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "electric-spit-projectile",
            starting_speed = 0.5,
            max_range = 50
          }
        }
      }
    },
    build_base_evolution_requirement = 0.5,
    autoplace = enemy_autoplace.enemy_worm_autoplace(5),
    call_for_help_radius = 40
  },


  {
    type = "corpse",
    name = "bob-big-explosive-worm-corpse",
    icon = "__base__/graphics/icons/big-worm-corpse.png",
    icon_size = 32,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-c[worm]-d[big]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    final_render_layer = "corpse",
    animation = worm_die_animation(scale_worm_big, bob_explosive_worm_tint)
  },

  {
    type = "corpse",
    name = "bob-big-fire-worm-corpse",
    icon = "__base__/graphics/icons/big-worm-corpse.png",
    icon_size = 32,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-c[worm]-e[big]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    final_render_layer = "corpse",
    animation = worm_die_animation(scale_worm_big, bob_fire_worm_tint)
  },

  {
    type = "corpse",
    name = "bob-big-poison-worm-corpse",
    icon = "__base__/graphics/icons/big-worm-corpse.png",
    icon_size = 32,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-c[worm]-f[big]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    final_render_layer = "corpse",
    animation = worm_die_animation(scale_worm_big, bob_poison_worm_tint)
  },

  {
    type = "corpse",
    name = "bob-big-piercing-worm-corpse",
    icon = "__base__/graphics/icons/big-worm-corpse.png",
    icon_size = 32,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-c[worm]-g[big]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    final_render_layer = "corpse",
    animation = worm_die_animation(scale_worm_big, bob_pierce_worm_tint)
  },

  {
    type = "corpse",
    name = "bob-big-electric-worm-corpse",
    icon = "__base__/graphics/icons/big-worm-corpse.png",
    icon_size = 32,
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-c[worm]-h[big]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    final_render_layer = "corpse",
    animation = worm_die_animation(scale_worm_big, bob_electric_worm_tint)
  },
}
)



data:extend(
{
  {
    type = "turret",
    name = "bob-giant-worm-turret",
    icon = "__base__/graphics/icons/big-worm.png",
    icon_size = 32,
    flags = {"placeable-player", "placeable-enemy", "not-repairable", "breaths-air"},
    max_health = 1000,
    order="b-b-i",
    subgroup="enemies",
    resistances =
    {
      {
        type = "physical",
        decrease = 10,
      },
      {
        type = "explosion",
        decrease = 10,
        percent = 35,
      },
    },
    healing_per_tick = 0.03,
    collision_box = {{-2.1, -1.8}, {2.1, 1.8}},
    selection_box = {{-2.1, -1.8}, {2.1, 1.8}},
    map_generator_bounding_box = {{-3.1, -2.8}, {3.1, 2.8}},
    shooting_cursor_size = 6,
    rotation_speed = 1,
    corpse = "bob-giant-worm-corpse",
    dying_explosion = "blood-explosion-big",
    dying_sound = make_worm_dying_sounds(1.0),
    folded_speed = 0.01,
    folded_animation = worm_folded_animation(bob_giant_scale, bob_giant_worm_tint),
    preparing_speed = 0.025,
    preparing_animation = worm_preparing_animation(bob_giant_scale, bob_giant_worm_tint, "forward"),
    prepared_speed = 0.015,
    prepared_animation = worm_prepared_animation(bob_giant_scale, bob_giant_worm_tint),
    starting_attack_speed = 0.03,
    starting_attack_animation = worm_start_attack_animation(bob_giant_scale, bob_giant_worm_tint),
    starting_attack_sound = make_worm_roars(1.0),
    ending_attack_speed = 0.03,
    ending_attack_animation = worm_end_attack_animation(bob_giant_scale, bob_giant_worm_tint),
    folding_speed = 0.015,
    folding_animation =  worm_preparing_animation(bob_giant_scale, bob_giant_worm_tint, "backward"),
    prepare_range = 30,
    attack_parameters =
    {
      type = "stream",
      ammo_category = "biological",
      damage_modifier = 84,
      cooldown = 4,
      range = 42,
      min_range = 0,
      projectile_creation_parameters = worm_shoot_shiftings(bob_giant_scale, bob_giant_scale * scale_worm_stream),
      use_shooter_direction = true,
      lead_target_for_projectile_speed = 0.2* 0.75 * 1.5 * 1.5, -- this is same as particle horizontal speed of flamethrower fire stream
      ammo_type =
      {
        category = "biological",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "stream",
            stream = "acid-stream-worm-behemoth",
            duration = 160,
            source_offset = {0.15, -0.5}
          }
        }
      },
    },
    build_base_evolution_requirement = 0.75,
    autoplace = enemy_autoplace.enemy_worm_autoplace(7),
    call_for_help_radius = 40
  },

  {
    type = "corpse",
    name = "bob-giant-worm-corpse",
    icon = "__base__/graphics/icons/big-worm-corpse.png",
    icon_size = 32,
    selection_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selectable_in_game = false,
    subgroup="corpses",
    order = "c[corpse]-c[worm]-i[giant]",
    flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-repairable", "not-on-map"},
    dying_speed = 0.01,
    final_render_layer = "corpse",
    animation = worm_die_animation(bob_giant_scale, bob_giant_worm_tint)
  },
}
)
