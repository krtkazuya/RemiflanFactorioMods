bobmods.ores.gold =
{
  name = "gold-ore",
  tint = {r = 1, g = 0.75, b = 0},
  map_color = {r=0.9, g=0.63, b=0},
  mining_time = 0.75,
  enabled = false,
  icon = "__bobores__/graphics/icons/gold-ore.png",
  stage_mult = 100,
  item =
  {
    create = true,
    subgroup = "bob-ores",
  },
  sprite =
  {
    sheet = 2
  },
--[[
  autoplace = 
  {
    create = true,
    starting_area = false,
    richness = 1,
    size = 1.2
  }
]]--
  autoplace = resource_autoplace.resource_autoplace_settings{
    name = "gold-ore",
    order = "c",
    base_density = 4,
    has_starting_area_placement = false,
    resource_index = resource_autoplace.get_next_resource_index(),
    regular_rq_factor_multiplier = 0.9,
  },
}

